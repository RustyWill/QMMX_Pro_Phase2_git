from memory_recall_engine import (
    recall_pattern_memory,
    recall_trade_memory,
    recall_recent_feedback
)
from pattern_resilience import get_resilience_floor, update_on_failure, update_on_success

def adjust_confidence_with_memory(pattern_id, base_score, ticker, success: bool = None):
    """
    Adjusts the confidence score of a pattern using:
    - Historical memory (win rate, avg confidence)
    - User feedback (Reject, Review Further)
    - Pattern resilience floor
    - Optional success result from most recent trade
    """
    memory = recall_pattern_memory(pattern_id)
    trades = recall_trade_memory(ticker=ticker, pattern_id=pattern_id)
    feedback = recall_recent_feedback()

    # Start from the base model score
    score = base_score

    # Boost or penalize based on pattern memory
    if memory:
        times_seen = memory[2]
        times_successful = memory[3]
        avg_conf = memory[4] or 0

        if times_seen >= 5:
            win_rate = times_successful / times_seen
            score += (win_rate - 0.5) * 0.4
            score += (avg_conf - 0.5) * 0.2

    # Feedback modifiers
    negative_feedback = [f for f in feedback if f[2] == pattern_id and f[3] == "Reject"]
    review_feedback = [f for f in feedback if f[2] == pattern_id and f[3] == "Review Further"]
    score -= 0.1 * len(negative_feedback)
    score -= 0.05 * len(review_feedback)

    # Apply resilience floor
    floor = get_resilience_floor(pattern_id)
    score = max(score, floor)

    # Track outcome if passed in
    if success is True:
        update_on_success(pattern_id)
    elif success is False:
        update_on_failure(pattern_id)

    return max(0.0, min(1.0, score))
