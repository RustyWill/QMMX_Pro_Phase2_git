import time
from datetime import datetime

class PortfolioTracker:
    def __init__(self, starting_balance=1000.00):
        self.balance = starting_balance
        self.open_positions = []
        self.closed_positions = []

    def execute_trade(self, contract, entry_price, trade_type):
        trade = {
            "contract": contract,
            "entry_price": entry_price,
            "current_price": entry_price,
            "profit": 0.0,
            "type": trade_type,
            "timestamp": time.time()
        }
        self.open_positions.append(trade)
        return trade

    def update_live_price(self, contract, current_price):
        for trade in self.open_positions:
            if trade["contract"] == contract:
                trade["current_price"] = current_price
                trade["profit"] = (current_price - trade["entry_price"]) * 100

    def close_trade(self, contract):
        for i, trade in enumerate(self.open_positions):
            if trade["contract"] == contract:
                trade["closed_timestamp"] = time.time()
                self.closed_positions.append(trade)
                self.open_positions.pop(i)
                self.balance += trade["profit"]
                return trade
        return None

    def get_portfolio(self):
        return {
            "balance": self.balance,
            "open_positions": self.open_positions,
            "closed_positions": self.closed_positions
        }
