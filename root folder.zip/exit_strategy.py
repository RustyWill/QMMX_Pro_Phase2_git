# exit_strategy.py

from diagnostic_monitor import diagnostic_monitor

class ExitStrategy:
    def __init__(self):
        self.max_hold_minutes = 12
        self.min_profit_pct = 0.25
        self.trailing_loss_pct = 0.15
        self.recorded_exits = []

    def should_exit(self, trade, current_price, current_time):
        try:
            entry_price = trade["entry_price"]
            entry_time = trade["entry_time"]
            direction = trade["direction"]

            held_minutes = (current_time - entry_time) / 60
            unrealized_pct = self._calculate_unrealized_pct(entry_price, current_price, direction)

            if unrealized_pct >= self.min_profit_pct:
                reason = "Target Reached"
            elif unrealized_pct <= -self.trailing_loss_pct:
                reason = "Trailing Stop Hit"
            elif held_minutes >= self.max_hold_minutes:
                reason = "Time Expired"
            else:
                return None  # Hold

            exit_data = {
                "trade_id": trade.get("id", None),
                "exit_time": current_time,
                "exit_price": current_price,
                "unrealized_pct": unrealized_pct,
                "reason": reason
            }

            self.recorded_exits.append(exit_data)
            diagnostic_monitor.ping("exit_planner")
            return exit_data

        except Exception as e:
            diagnostic_monitor.report_error("exit_planner", f"Exit check failed: {e}")
            return None

    def _calculate_unrealized_pct(self, entry, current, direction):
        if direction == "long":
            return (current - entry) / entry
        else:
            return (entry - current) / entry
