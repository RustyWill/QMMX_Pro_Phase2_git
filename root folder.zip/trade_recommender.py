import sqlite3

# trade_recommender.py
# Provides functions to recommend trades based on patterns
# and fetch the latest stored trade recommendations.

def recommend_trade(pattern):
    if pattern.get("confidence", 0) < 0.7:
        return None

    price = pattern.get("structure", {}).get("entry_price", 0)
    timestamp = pattern.get("timestamp", "")
    direction = pattern.get("structure", {}).get("direction", "up")

    rec = {
        "symbol": pattern.get("symbol", ""),
        "direction": direction,
        "entry_price": price,
        "strike": round(price),
        "type": "call" if direction == "up" else "put",
        "timestamp": timestamp,
        "pattern_id": pattern.get("pattern_name", "unknown")
    }
    return rec


def get_latest_recommendations(limit=10):
    """
    Returns the most recent trade recommendations stored in the DB.
    Ensures the table exists before querying.
    """
    try:
        conn = sqlite3.connect("qmmx.db")
        cur = conn.cursor()

        # Ensure the recommendations table exists
        cur.execute("""
            CREATE TABLE IF NOT EXISTS trade_recommendations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT,
                direction TEXT,
                entry_price REAL,
                strike REAL,
                type TEXT,
                timestamp TEXT,
                pattern_id TEXT
            )
        """)
        conn.commit()

        # Fetch latest recommendations
        cur.execute(
            "SELECT * FROM trade_recommendations ORDER BY timestamp DESC LIMIT ?",
            (limit,)
        )
        columns = [desc[0] for desc in cur.description]
        rows = cur.fetchall()
        conn.close()

        # Build list of dicts
        results = [dict(zip(columns, row)) for row in rows]
        return results
    except Exception as e:
        print(f"❌ Error loading trade recommendations: {e}")
        return []
