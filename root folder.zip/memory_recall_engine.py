import sqlite3
from datetime import datetime, timedelta
import pandas as pd

DB_PATH = "qmmx_memory.db"

def get_latest_module_status():
    # Placeholder logic - replace with actual module status retrieval
    return {
        "ml_engine": "active",
        "pattern_recognition": "active",
        "trade_recommender": "active",
        "exit_strategy": "active"
    }

def get_connection():
    conn = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL;")
    return conn

# 1. Recall pattern memory by ID
def recall_pattern_memory(pattern_id: str):
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM patterns_memory WHERE id = ?", (pattern_id,))
        return cursor.fetchone()

# 2. Recall trade memory by ticker or pattern
def recall_trade_memory(ticker: str = None, pattern_id: str = None):
    with get_connection() as conn:
        cursor = conn.cursor()
        query = "SELECT * FROM trades_history WHERE 1=1"
        params = []
        if ticker:
            query += " AND ticker = ?"
            params.append(ticker)
        if pattern_id:
            query += " AND pattern_id = ?"
            params.append(pattern_id)
        cursor.execute(query, tuple(params))
        return cursor.fet
