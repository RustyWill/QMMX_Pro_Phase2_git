#!/usr/bin/env python3
# ml_engine.py

import os
import time
import traceback

from trade_recommender import recommend_trade, get_latest_recommendations
from pattern_evolution import PatternEvolutionTracker
from backend.pattern_resilience import record_resilience
from price_feed import get_latest_price
from polygon_io_provider import get_option_chain
from qmms_pattern_discovery import PatternDiscoveryEngine
from diagnostic_monitor import diagnostic_monitor
from portfolio_tracker import PortfolioTracker
from exit_strategy import ExitStrategy

# ---------------------------------------------------------------------------
# Configuration (override via env vars if you like)
# ---------------------------------------------------------------------------
SYMBOL          = os.getenv("QMMX_SYMBOL", "SPY")
EXPIRATION_DATE = os.getenv("QMMX_EXPIRATION", "2025-08-02")
POLL_INTERVAL   = float(os.getenv("QMMX_POLL_INTERVAL", "1.0"))

# ---------------------------------------------------------------------------
# Initialize all sub-systems
# ---------------------------------------------------------------------------
discovery_engine  = PatternDiscoveryEngine()
evolution_tracker = PatternEvolutionTracker()
exit_engine       = ExitStrategy()
portfolio         = PortfolioTracker()

print("✅ QMMX ML Engine initialized.")
print(f"  Symbol: {SYMBOL}, Expiration: {EXPIRATION_DATE}, Poll Interval: {POLL_INTERVAL}s")

# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------
def run_ml_engine():
    while True:
        try:
            # 1) Fetch the live option chain for SPY (hard-coded per your current spec)
            option_chain = get_option_chain(SYMBOL, EXPIRATION_DATE, limit=100)
            print(f"[ML] Fetched option_chain ({len(option_chain)} contracts)")

            # 2) Discover any new patterns from price touches
            current_price = get_latest_price(SYMBOL)
            print(f"[ML] Current price tick: {current_price}")
            features = {
                "price": current_price,
                "direction": "up",           # you can refine this later
                "price_history": [],         # plug in your stored history if you have it
                "volume_profile": {},        # likewise
            }
            levels = []                      # fill in with your dynamic levels when ready

            pattern = discovery_engine.discover(features, levels)
            print(f"[ML] Patterns found: {pattern!r}")
            if pattern and isinstance(pattern, dict):
                print("🔍 Discovered pattern:", pattern)

                # 3) Get the latest trade recommendations
                recs = get_latest_recommendations()
                print(f"[ML] Trade recommendations retrieved: {recs!r}")
                if recs:
                    print("💡 Trade recommendations:", recs)

                    # 4) Execute the first recommendation
                    first = recs[0]
                    print(f"[ML] Executing first rec: {first!r}")
                    contract    = first.get("option_contract") or first.get("contract")
                    entry_price = first["entry_price"]
                    direction   = first.get("direction")

                    portfolio.execute_trade(contract, entry_price, direction)
                    print(f"✅ Executed trade: {contract} @ {entry_price} ({direction})")

                    # 5) Record the outcome for pattern evolution & resilience
                    evolution_tracker.record_pattern_result(pattern, True)
                    record_resilience(pattern)

                    # 6) Check for an exit signal on that same contract
                    now_price   = get_latest_price(SYMBOL)
                    exit_signal = exit_engine.should_exit(first, now_price, time.time())
                    print(f"[ML] Exit check: now_price={now_price}, signal={exit_signal}")
                    if exit_signal:
                        portfolio.close_trade(contract)
                        print(f"🔒 Exited trade: {contract}")

            # 7) Ping the diagnostic monitor so your UI turns the ml_engine green
            diagnostic_monitor.ping("ml_engine")

        except Exception as e:
            # Report any crash in the UI and print a traceback
            diagnostic_monitor.report_error("ml_engine", str(e))
            traceback.print_exc()

        time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    run_ml_engine()
