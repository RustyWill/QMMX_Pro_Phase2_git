# diagnostic_monitor.py

import time
import threading

class QDiagnosticMonitor:
    def __init__(self):
        self.status = {
            'data_provider': {'active': False, 'last_ping': None, 'error': None},
            'ml_engine': {'active': False, 'last_ping': None, 'error': None},
            'pattern_discovery': {'active': False, 'last_ping': None, 'error': None},
            'pattern_recognizer': {'active': False, 'last_ping': None, 'error': None},
            'strategy_engine': {'active': False, 'last_ping': None, 'error': None},
            'entry_planner': {'active': False, 'last_ping': None, 'error': None},
            'exit_planner': {'active': False, 'last_ping': None, 'error': None},
            'upgrade_monitor': {'active': False, 'last_ping': None, 'error': None},
            'contact_evaluator': {'active': False, 'last_ping': None, 'error': None},
            'portfolio_tracker': {'active': False, 'last_ping': None, 'error': None},
        }
        self.lock = threading.Lock()

    def ping(self, module_name):
        with self.lock:
            if module_name in self.status:
                self.status[module_name]['active'] = True
                self.status[module_name]['last_ping'] = time.strftime("%H:%M:%S")
                self.status[module_name]['error'] = None

    def report_error(self, module_name, error_message):
        with self.lock:
            if module_name in self.status:
                self.status[module_name]['active'] = False
                self.status[module_name]['error'] = error_message

    def get_status(self):
        with self.lock:
            return self.status.copy()

    # ✅ This was missing – now added:
    def get_all_module_status(self):
        with self.lock:
            return self.status.copy()

# Instantiate global monitor
diagnostic_monitor = QDiagnosticMonitor()
