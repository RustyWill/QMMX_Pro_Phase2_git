import sqlite3
import json

# settings_store.py
# Stores persistent settings like API keys and alert phone numbers in SQLite.

def save_settings(polygon_api_key, alert_phone_numbers):
    """
    Save the Polygon.io API key and alert phone numbers list into the settings table.
    """
    try:
        conn = sqlite3.connect("qmmx.db")
        cur = conn.cursor()
        # Ensure the settings table exists
        cur.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """
        )
        # Upsert the API key
        cur.execute(
            "REPLACE INTO settings (key, value) VALUES (?, ?)"
        , ("polygon_api_key", polygon_api_key))
        # Upsert the phone numbers as JSON string
        cur.execute(
            "REPLACE INTO settings (key, value) VALUES (?, ?)"
        , ("alert_phone_numbers", json.dumps(alert_phone_numbers)))
        conn.commit()
    except Exception as e:
        print(f"❌ Error saving settings: {e}")
        raise
    finally:
        conn.close()
