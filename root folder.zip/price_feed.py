# price_feed.py
from polygon_io_provider import get_live_stock_price

def get_latest_price(symbol):
    """
    Proxy to live Polygon stock price.
    """
    return get_live_stock_price(symbol)
