#!/usr/bin/env python3
# app.py

from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
import time
import os

from backend.pattern_resilience import record_resilience
from exit_strategy import ExitStrategy
from trade_recommender import get_latest_recommendations
from diagnostic_monitor import QDiagnosticMonitor
from pattern_memory_engine import get_current_pattern, mark_pattern_decision
from alerts import get_current_alerts
from qmms_pattern_discovery import PatternDiscoveryEngine
from price_feed import get_latest_price as get_live_price
from settings_store import save_settings
from portfolio_tracker import PortfolioTracker
from polygon_io_provider import get_live_stock_price as get_option_price
from pattern_evolution import update_pattern_weights

# ─── App Setup ─────────────────────────────────────────────────────

app = Flask(__name__)
CORS(app)

# ─── Helpers / Globals ────────────────────────────────────────────

diagnostic_monitor = QDiagnosticMonitor()
exit_strategy      = ExitStrategy()
disc_engine        = PatternDiscoveryEngine()
portfolio_tracker  = PortfolioTracker()

DB_PATH = os.getenv("QMMX_DB", "qmmx.db")

# ─── Initialize / Migrate DB ───────────────────────────────────────

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur  = conn.cursor()

    # 1) price_levels table (Text Level Entry)
    cur.execute("""
      CREATE TABLE IF NOT EXISTS price_levels (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        color        TEXT    NOT NULL,
        level_type   TEXT    NOT NULL,
        level_index  INTEGER NOT NULL,
        price        REAL    NOT NULL,
        created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    """)

    # 2) trades_history (for Memory Viewer)
    cur.execute("""
      CREATE TABLE IF NOT EXISTS trades_history (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp    TEXT,
        contract     TEXT,
        direction    TEXT,
        price        REAL
      )
    """)

    # 3) patterns_memory (if you plan to store reviewed patterns)
    cur.execute("""
      CREATE TABLE IF NOT EXISTS patterns_memory (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        name            TEXT,
        confidence      REAL,
        discovered_at   TEXT
      )
    """)

    conn.commit()
    conn.close()

# Call once on startup
init_db()

# ─── Diagnostics ──────────────────────────────────────────────────

@app.route("/module_status")
def module_status():
    try:
        status = diagnostic_monitor.get_status()
        return jsonify(success=True, status=status)
    except Exception as e:
        return jsonify(success=False, error=str(e)), 200

# ─── Price Feed ───────────────────────────────────────────────────

@app.route("/price")
def price():
    symbol = request.args.get("symbol", "SPY")
    try:
        p = get_live_price(symbol)
        return jsonify(success=True, price=p)
    except Exception as e:
        return jsonify(success=False, error=str(e)), 200

# ─── Trade Recommendations ────────────────────────────────────────

@app.route("/get_recommendations")
def get_recs():
    recs = get_latest_recommendations()
    return jsonify(success=True, recommendations=recs)

# ─── Alerts ───────────────────────────────────────────────────────

@app.route("/get_alerts")
def get_alerts():
    alerts = get_current_alerts()
    return jsonify(success=True, alerts=alerts)

# ─── Memory Viewer ────────────────────────────────────────────────

@app.route("/view_memory/<table_name>")
def view_memory(table_name):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    try:
        cur.execute(f"SELECT * FROM {table_name} ORDER BY rowid DESC LIMIT 100")
        rows = [dict(r) for r in cur.fetchall()]
        return jsonify(success=True, rows=rows)
    except sqlite3.OperationalError as e:
        # missing table or bad SQL → front-end will display “No data available.”
        return jsonify(success=False, error=str(e)), 200
    finally:
        conn.close()

# ─── Pattern Review ───────────────────────────────────────────────

@app.route("/get_current_pattern")
def fetch_pattern():
    pat = get_current_pattern()
    return jsonify(success=bool(pat), pattern=pat)

@app.route("/mark_pattern_decision", methods=["POST"])
def submit_pattern_decision():
    data = request.get_json() or {}
    ok   = mark_pattern_decision(data.get("pattern_id"), data.get("decision"))
    return jsonify(success=ok)

# ─── Text Level Entry ─────────────────────────────────────────────

@app.route("/submit_levels", methods=["POST"])
def submit_levels():
    data = request.get_json() or {}
    levels_by_color = data.get("levels_by_color", {})

    conn = sqlite3.connect(DB_PATH)
    cur  = conn.cursor()

    # (price_levels table already created in init_db())
    cur.execute("DELETE FROM price_levels")

    for color, groups in levels_by_color.items():
        for level_type in ("solid", "dashed"):
            for idx, price in enumerate(groups.get(level_type, [])):
                try:
                    p = float(price)
                except (TypeError, ValueError):
                    continue
                cur.execute("""
                  INSERT INTO price_levels
                    (color, level_type, level_index, price)
                  VALUES (?, ?, ?, ?)
                """, (color, level_type, idx, p))

    conn.commit()
    conn.close()
    return jsonify(success=True)

# ─── Portfolio (simulated) ───────────────────────────────────────

@app.route("/get_portfolio")
def get_portfolio():
    state = portfolio_tracker.get_portfolio()
    for pos in state.get("open_positions", []):
        current = get_option_price(pos["contract"])
        pos["current_price"] = current
        pos["profit"]        = (current - pos["entry_price"]) * 100
    return jsonify(success=True, **state)

# ─── Settings ────────────────────────────────────────────────────

@app.route("/settings", methods=["POST"])
def settings():
    data    = request.get_json() or {}
    api_key = data.get("polygon_api_key", "")
    phones  = data.get("alert_phone_numbers", [])
    ok      = save_settings(api_key, phones)
    return jsonify(success=ok)

# ─── Pattern Discovery ────────────────────────────────────────────

@app.route("/analyze")
def analyze_patterns():
    pattern = disc_engine.discover(features={}, levels=[])
    return jsonify(patterns=pattern or [])

# ─── Pattern Evolution ────────────────────────────────────────────

@app.route("/evolve_patterns")
def evolve_patterns():
    try:
        update_pattern_weights()
        return jsonify(success=True)
    except Exception as e:
        return jsonify(success=False, error=str(e)), 200

# ─── Exit Strategy & Resilience ──────────────────────────────────

@app.route("/exit_strategy", methods=["POST"])
def exit_strategy_route():
    params = request.get_json() or {}
    result = exit_strategy.evaluate(**params)
    return jsonify(success=True, **result)

@app.route("/record_resilience", methods=["POST"])
def resilience_route():
    data = request.get_json() or {}
    record_resilience(**data)
    return jsonify(success=True)

# ─── Live Option Price ───────────────────────────────────────────

@app.route("/live_option_price")
def live_option_price():
    contract = request.args.get("contract", "")
    price    = get_option_price(contract)
    return jsonify(success=True, price=price)

# ─── Main ────────────────────────────────────────────────────────

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
