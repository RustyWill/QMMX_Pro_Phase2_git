# pattern_evolution.py

import sqlite3
from datetime import datetime

DB_PATH = "qmmx.db"


def get_connection():
    """
    Return a SQLite connection with WAL mode enabled.
    """
    conn = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL;")
    return conn


class PatternEvolutionTracker:
    def __init__(self):
        self._create_table()

    def _create_table(self):
        """
        Ensure the pattern_evolution table exists.
        """
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS pattern_evolution (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT,
                    pattern_name TEXT,
                    confidence REAL,
                    structure TEXT,
                    outcome TEXT
                )
            """)
            conn.commit()

    def record_pattern_result(self, pattern, success=True):
        """
        Insert a record of a pattern outcome into the evolution table.
        """
        timestamp = datetime.now().isoformat()
        name = pattern.get("pattern_name", "unknown")
        confidence = pattern.get("confidence", 0)
        structure = str(pattern.get("structure", {}))
        outcome = "SUCCESS" if success else "FAILURE"

        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO pattern_evolution (timestamp, pattern_name, confidence, structure, outcome)
                VALUES (?, ?, ?, ?, ?)
            """, (timestamp, name, confidence, structure, outcome))
            conn.commit()

    def close(self):
        # No persistent connection to close
        pass


def update_pattern_weights():
    """
    Recalculate weights for each pattern based on success/failure counts
    in the pattern_evolution table, and update the patterns table.
    """
    # Compute counts
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT pattern_name,
               SUM(CASE WHEN outcome='SUCCESS' THEN 1 ELSE 0 END) AS succ,
               SUM(CASE WHEN outcome='FAILURE' THEN 1 ELSE 0 END) AS fail
        FROM pattern_evolution
        GROUP BY pattern_name
    """)
    rows = cur.fetchall()
    conn.close()

    # Ensure patterns table exists
    conn2 = sqlite3.connect(DB_PATH)
    cur2 = conn2.cursor()
    cur2.execute("""
        CREATE TABLE IF NOT EXISTS patterns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pattern_name TEXT UNIQUE,
            weight REAL DEFAULT 0
        )
    """)
    conn2.commit()

    # Update weights
    for pattern_name, succ, fail in rows:
        total = succ + fail
        if total > 0:
            weight = succ / total
            cur2.execute(
                """
                INSERT INTO patterns (pattern_name, weight)
                VALUES (?, ?)
                ON CONFLICT(pattern_name) DO UPDATE SET weight=excluded.weight
                """, (pattern_name, weight)
            )
    conn2.commit()
    conn2.close()
